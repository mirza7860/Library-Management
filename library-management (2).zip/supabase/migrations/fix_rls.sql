-- This SQL script modifies the RLS policies to allow public access for authentication

-- First, let's make sure we can access the tables for authentication
ALTER POLICY "librarian_all_access" ON "librarians"
  USING (true);

ALTER POLICY "student_read_own_data" ON "borrowers"
  USING (true);

-- Create a new policy to allow public access to librarians table for authentication
CREATE POLICY "public_auth_librarians" ON "librarians" 
  FOR SELECT USING (true);

-- Create a new policy to allow public access to borrowers table for authentication
CREATE POLICY "public_auth_borrowers" ON "borrowers" 
  FOR SELECT USING (true);

