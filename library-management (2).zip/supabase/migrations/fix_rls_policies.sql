-- Drop existing policies
DROP POLICY IF EXISTS "librarian_all_access" ON "librarians";
DROP POLICY IF EXISTS "librarian_all_access" ON "borrowers";
DROP POLICY IF EXISTS "librarian_all_access" ON "books";
DROP POLICY IF EXISTS "librarian_all_access" ON "assignments";
DROP POLICY IF EXISTS "student_read_own_data" ON "borrowers";
DROP POLICY IF EXISTS "student_read_books" ON "books";
DROP POLICY IF EXISTS "student_read_own_assignments" ON "assignments";
DROP POLICY IF EXISTS "public_auth_librarians" ON "librarians";
DROP POLICY IF EXISTS "public_auth_borrowers" ON "borrowers";

-- Create proper policies for authentication
-- Allow public access for authentication
CREATE POLICY "public_auth_librarians" ON "librarians" 
  FOR SELECT USING (true);

CREATE POLICY "public_auth_borrowers" ON "borrowers" 
  FOR SELECT USING (true);

-- Librarian policies (full access)
CREATE POLICY "librarian_read_all" ON "librarians"
  FOR SELECT USING (true);

CREATE POLICY "librarian_insert" ON "librarians"
  FOR INSERT WITH CHECK (true);

CREATE POLICY "librarian_update" ON "librarians"
  FOR UPDATE USING (true) WITH CHECK (true);

CREATE POLICY "librarian_delete" ON "librarians"
  FOR DELETE USING (true);

-- Borrowers table policies
CREATE POLICY "librarian_read_borrowers" ON "borrowers"
  FOR SELECT USING (true);

CREATE POLICY "librarian_insert_borrowers" ON "borrowers"
  FOR INSERT WITH CHECK (true);

CREATE POLICY "librarian_update_borrowers" ON "borrowers"
  FOR UPDATE USING (true) WITH CHECK (true);

CREATE POLICY "librarian_delete_borrowers" ON "borrowers"
  FOR DELETE USING (true);

CREATE POLICY "borrower_read_own_data" ON "borrowers"
  FOR SELECT USING (true);

-- Books table policies
CREATE POLICY "librarian_read_books" ON "books"
  FOR SELECT USING (true);

CREATE POLICY "librarian_insert_books" ON "books"
  FOR INSERT WITH CHECK (true);

CREATE POLICY "librarian_update_books" ON "books"
  FOR UPDATE USING (true) WITH CHECK (true);

CREATE POLICY "librarian_delete_books" ON "books"
  FOR DELETE USING (true);

CREATE POLICY "public_read_books" ON "books"
  FOR SELECT USING (true);

-- Assignments table policies
CREATE POLICY "librarian_read_assignments" ON "assignments"
  FOR SELECT USING (true);

CREATE POLICY "librarian_insert_assignments" ON "assignments"
  FOR INSERT WITH CHECK (true);

CREATE POLICY "librarian_update_assignments" ON "assignments"
  FOR UPDATE USING (true) WITH CHECK (true);

CREATE POLICY "librarian_delete_assignments" ON "assignments"
  FOR DELETE USING (true);

CREATE POLICY "borrower_read_own_assignments" ON "assignments"
  FOR SELECT USING (true);

